
from __future__ import print_function
import sys


def generate_wrapper(filename, func_list, modulename, log_file, include_headers, \
				  log_wrap_funcs_list, log_pre_wrap_funcs_list):
        """static gotcha_wrappee_handle_t WRAP_Orig_Func_handle;
static int (*WRAP_Orig_Func) (int param);
static int dissectio_Orig_Func (int param){
	printf("Orig_Func\n");
        WRAP_Orig_Func = gotcha_get_wrappee(WRAP_Orig_Func_handle);
        return WARP_Orig_Func ? (WRAP_Orig_Func(param) ) : 0;
}
"""
	f = open(filename, "w")	
	# write each function wrapper
	for function in func_list:
	
		#write shared wrapper
                f.write("void" + " " + function.wraper + "_mywrap" + 
						"(" + function.arg_string + ");\n")
        f.write("\n\n"); 
	for function in func_list:
                f.write("void" + " " + function.wraper + "_mywrap" + 
						"(" + function.arg_string + ")\n{\n")
		f.write("  meta_api_count++;\n");
		f.write("  return ;\n");
		f.write("}\n\n");
		
        f.write("\n")



