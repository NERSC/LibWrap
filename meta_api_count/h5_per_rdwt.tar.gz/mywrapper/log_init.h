#include <stdlib.h>
#include <stdio.h>
#include <mpi.h>
#include "h5_wrap.h"

void _log_init();
