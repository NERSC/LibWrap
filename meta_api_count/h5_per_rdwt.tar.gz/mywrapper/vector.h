/*
The code for dynamic vector is adopted from lodepng - https://github.com/lvandeve/lodepng  
*/
#include <stdlib.h>

/*dynamic vector of unsigned ints*/
typedef struct uivector {
  unsigned* data;
  size_t size; /*size in number of unsigned longs*/
  size_t allocsize; /*allocated size in bytes*/
} uivector;

typedef struct ullvector {
  unsigned long long* data;
  size_t size; /*size in number of unsigned longs*/
  size_t allocsize; /*allocated size in bytes*/
} ullvector;




void uivector_cleanup(void* p);
unsigned uivector_reserve(uivector* p, size_t allocsize); 
unsigned uivector_resize(uivector* p, size_t size);
unsigned uivector_resizev(uivector* p, size_t size, unsigned value); 
void uivector_init(uivector* p); 
unsigned uivector_push_back(uivector* p, unsigned c); 

/*same as above but with unsigned long long */
void ullvector_cleanup(void* p);
unsigned ullvector_reserve(ullvector* p, size_t allocsize); 
unsigned ullvector_resize(ullvector* p, size_t size);
unsigned ullvector_resizev(ullvector* p, size_t size, unsigned value); 
void ullvector_init(ullvector* p); 
unsigned ullvector_push_back(ullvector* p, unsigned c); 

