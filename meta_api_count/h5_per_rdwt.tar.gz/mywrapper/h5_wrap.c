#include "h5_wrap.h"

long long serial_read_data = 0;
long long serial_write_data = 0;

struct posix_api_counts loc_psx_cnts;
struct posix_api_counts glo_psx_cnts;

struct h5_api_counts loc_serial_api_counts, glo_serial_api_counts;
struct h5_api_counts loc_parallel_api_counts, glo_parallel_api_counts;

struct buff_sz loc_psx_buff_sz, glo_psx_buff_sz;
struct buff_sz loc_ph5_buff_sz, loc_h5_buff_sz;
struct buff_sz glo_ph5_buff_sz, glo_h5_buff_sz;

long long meta_api_count=0;

int flag_h5dread=0;
int flag_h5pdread=0;
int flag_h5dwrite=0;
int flag_h5pdwrite=0;

int h5Dread_count;
int h5Dwrite_count;
int h5pDread_count;
int h5pDwrite_count;

uivector loc_psx_per_h5dread; 
uivector loc_psx_per_h5dwrite; 
uivector glo_psx_per_h5dread;
uivector glo_psx_per_h5dwrite;
uivector loc_psx_per_h5pdread; 
uivector loc_psx_per_h5pdwrite; 
uivector glo_psx_per_h5pdread;
uivector glo_psx_per_h5pdwrite;

ullvector loc_psx_buff_per_h5dread;
ullvector loc_psx_buff_per_h5dwrite;
ullvector glo_psx_buff_per_h5dread;
ullvector glo_psx_buff_per_h5dwrite;
ullvector loc_psx_buff_per_h5pdread;
ullvector loc_psx_buff_per_h5pdwrite;
ullvector glo_psx_buff_per_h5pdread;
ullvector glo_psx_buff_per_h5pdwrite;


json_t *json_root; 
struct log_info job_log;

/*FUTURE TODO: C version of overloading*/
double get_mean_ui(unsigned * arr, int len)
{
  //FUTURE TODO: This can cause overflow 
  int i;
  unsigned sum=0;
  for (i=0;i<len;i++){
    sum+=arr[i];
  }
  return (double) sum/len;
}


double get_std_ui(unsigned * arr, int len)
{
  if (len<=1){
    return (double)0;
  }
  double mean = get_mean_ui(arr, len);
  double s=0;
  int i;
  for(i=0;i<len;i++){
    s+=pow(((double)arr[i]-mean),2);
  }
  s=sqrt(s/((double)len-1));
  return s;
}


double get_mean_ull(unsigned long long* arr, int len)
{
  //FUTURE FIXME: This can cause overflow 
  int i;
  unsigned long long sum=0;
  for (i=0;i<len;i++){
    sum+=arr[i];
  }
  return (double) sum/len;
}


double get_std_ull(unsigned long long* arr, int len)
{
  if (len<=1){
    return (double)0;
  }
  double mean = get_mean_ull(arr, len);
  double s=0;
  int i;
  for(i=0;i<len;i++){
    s+=pow(((double)arr[i]-mean),2);
  }
  s=sqrt(s/((double)len-1));
  return s;
}


void crt_json_log()
{
  json_root = json_object();
  json_object_set_new(json_root, "category", json_string("MODS") );
  json_object_set_new(json_root, "name", json_string("libwrap-hdf5") );
  json_object_set_new(json_root, "uid", json_integer(job_log.uid) );
  json_object_set_new(json_root, "nersc host", json_string(job_log.host));
  json_object_set_new(json_root, "hostname", json_string(job_log.hostname));
  json_object_set_new(json_root, "user", json_string(job_log.user));
  json_object_set_new(json_root, "slurm number of nodes", json_string(job_log.slurm_job_num_nodes));
  json_object_set_new(json_root, "slurm job account", json_string(job_log.slurm_job_account));
  json_object_set_new(json_root, "nodetype", json_string(job_log.nodetype));
  json_object_set_new(json_root, "is_compute_node", json_integer(job_log.is_compute));
  json_object_set_new(json_root, "slurm job id", json_string(job_log.slurm_job_id));
  
  //TODO: JANSSON does not handle unsigned int
  /* Serial Counts */
  json_object_set_new(json_root, "serial fcreate count", json_integer(glo_serial_api_counts.fcreate_count));
  json_object_set_new(json_root, "serial fopen count", json_integer(glo_serial_api_counts.fopen_count));
  json_object_set_new(json_root, "serial acreate count", json_integer(glo_serial_api_counts.acreate_count));
  json_object_set_new(json_root, "serial aopen count", json_integer(glo_serial_api_counts.aopen_count));
  json_object_set_new(json_root, "serial aread count", json_integer(glo_serial_api_counts.aread_count));
  json_object_set_new(json_root, "serial awrite count", json_integer(glo_serial_api_counts.awrite_count));
  json_object_set_new(json_root, "serial dcreate count", json_integer(glo_serial_api_counts.dcreate_count));
  json_object_set_new(json_root, "serial dopen count", json_integer(glo_serial_api_counts.dopen_count));
  json_object_set_new(json_root, "serial dread count", json_integer(glo_serial_api_counts.dread_count));
  json_object_set_new(json_root, "serial dwrite count", json_integer(glo_serial_api_counts.dwrite_count));
  json_object_set_new(json_root, "serial gcreate count", json_integer(glo_serial_api_counts.gcreate_count));
  json_object_set_new(json_root, "serial gopen count", json_integer(glo_serial_api_counts.gopen_count));
  json_object_set_new(json_root, "posix read count", json_integer(glo_psx_cnts.read_count));
  json_object_set_new(json_root, "posix write count", json_integer(glo_psx_cnts.write_count));
  json_object_set_new(json_root, "Total meta api count", json_integer(meta_api_count));
 
  /* Parallel Counts */
  json_object_set_new(json_root, "parallel fcreate count", json_integer(glo_parallel_api_counts.fcreate_count));
  json_object_set_new(json_root, "parallel fopen count", json_integer(glo_parallel_api_counts.fopen_count));
  json_object_set_new(json_root, "parallel dread count", json_integer(glo_parallel_api_counts.dread_count));
  json_object_set_new(json_root, "parallel dwrite count", json_integer(glo_parallel_api_counts.dwrite_count));

  /* Data Read/Write */ 
  json_object_set_new(json_root, "serial hdf5 dataset read size", json_integer(glo_h5_buff_sz.read));
  json_object_set_new(json_root, "serial hdf5 dataset write size", json_integer(glo_h5_buff_sz.write));
  json_object_set_new(json_root, "parallel hdf5 dataset read size", json_integer(glo_ph5_buff_sz.read));
  json_object_set_new(json_root, "parallel hdf5 dataset write size", json_integer(glo_ph5_buff_sz.write));
  json_object_set_new(json_root, "posix dataset read size", json_integer(glo_psx_buff_sz.read));
  json_object_set_new(json_root, "posix dataset write size", json_integer(glo_psx_buff_sz.write));

  int i;
  json_t* json_per_psx_stats = json_object();
  
  /*read calls*/
  json_t* ary_psx_per_h5dread = json_array();
  for (i=0; i<glo_psx_per_h5dread.size; i++){
    json_array_append_new(ary_psx_per_h5dread, json_integer(glo_psx_per_h5dread.data[i]));
  }
  json_object_set_new(json_per_psx_stats, "posix read calls", ary_psx_per_h5dread); 

  double mean_psx_per_h5dread = get_mean_ui(glo_psx_per_h5dread.data, glo_psx_per_h5dread.size);
  double std_psx_per_h5dread = get_std_ui(glo_psx_per_h5dread.data, 
						glo_psx_per_h5dread.size);
  
  json_object_set_new(json_per_psx_stats, "mean posix read calls", 
						json_real(mean_psx_per_h5dread));
  json_object_set_new(json_per_psx_stats, "std posix read calls", 
						json_real(std_psx_per_h5dread));
  /*pread calls*/
  json_t* ary_psx_per_h5pdread = json_array();
  for (i=0; i<glo_psx_per_h5pdread.size; i++){
    json_array_append_new(ary_psx_per_h5pdread, json_integer(glo_psx_per_h5pdread.data[i]));
  }
  json_object_set_new(json_per_psx_stats, "posix read calls parallel", ary_psx_per_h5pdread); 

  double mean_psx_per_h5pdread = get_mean_ui(glo_psx_per_h5pdread.data, glo_psx_per_h5pdread.size);
  double std_psx_per_h5pdread = get_std_ui(glo_psx_per_h5pdread.data, 
						glo_psx_per_h5pdread.size);
  
  json_object_set_new(json_per_psx_stats, "mean posix read calls parallel", 
						json_real(mean_psx_per_h5pdread));
  json_object_set_new(json_per_psx_stats, "std posix read calls parallel", 
						json_real(std_psx_per_h5pdread));
  
  /*read buff*/ 
  json_t* ary_psx_buff_per_h5dread = json_array();
  for (i=0; i<glo_psx_buff_per_h5dread.size; i++){
    json_array_append_new(ary_psx_buff_per_h5dread, 
			json_integer(glo_psx_buff_per_h5dread.data[i]));
  }
  json_object_set_new(json_per_psx_stats, "posix read size", 
						ary_psx_buff_per_h5dread); 
  
  double mean_psx_buff_per_h5dread = get_mean_ull(glo_psx_buff_per_h5dread.data, 
						glo_psx_buff_per_h5dread.size);
  double std_psx_buff_per_h5dread = get_std_ull(glo_psx_buff_per_h5dread.data, 
						glo_psx_buff_per_h5dread.size);
  
  json_object_set_new(json_per_psx_stats, "mean posix read size", 
						json_real(mean_psx_buff_per_h5dread));
  json_object_set_new(json_per_psx_stats, "std posix read size", 
						json_real(std_psx_buff_per_h5dread));

  /*pread buff*/ 
  json_t* ary_psx_buff_per_h5pdread = json_array();
  for (i=0; i<glo_psx_buff_per_h5pdread.size; i++){
    json_array_append_new(ary_psx_buff_per_h5pdread, 
			json_integer(glo_psx_buff_per_h5pdread.data[i]));
  }
  json_object_set_new(json_per_psx_stats, "posix read size parallel", 
						ary_psx_buff_per_h5pdread); 
  
  double mean_psx_buff_per_h5pdread = get_mean_ull(glo_psx_buff_per_h5pdread.data, 
						glo_psx_buff_per_h5pdread.size);
  double std_psx_buff_per_h5pdread = get_std_ull(glo_psx_buff_per_h5pdread.data, 
						glo_psx_buff_per_h5pdread.size);
  
  json_object_set_new(json_per_psx_stats, "mean posix read size parallel", 
						json_real(mean_psx_buff_per_h5pdread));
  json_object_set_new(json_per_psx_stats, "std posix read size parllel", 
						json_real(std_psx_buff_per_h5pdread));


  /*write calls*/
  json_t* ary_psx_per_h5dwrite = json_array();
  for (i=0; i<glo_psx_per_h5dwrite.size; i++){
    json_array_append_new(ary_psx_per_h5dwrite, json_integer(glo_psx_per_h5dwrite.data[i]));
  }
  json_object_set_new(json_per_psx_stats, "posix write calls", ary_psx_per_h5dwrite); 

  double mean_psx_per_h5dwrite = get_mean_ui(glo_psx_per_h5dwrite.data, 
						glo_psx_per_h5dwrite.size);
  double std_psx_per_h5dwrite = get_std_ui(glo_psx_per_h5dwrite.data, 
						glo_psx_per_h5dwrite.size);
  
  json_object_set_new(json_per_psx_stats, "mean posix write calls", 
						json_real(mean_psx_per_h5dwrite));
  json_object_set_new(json_per_psx_stats, "std posix write calls", 
						json_real(std_psx_per_h5dwrite));
  
  /*pwrite calls*/
  json_t* ary_psx_per_h5pdwrite = json_array();
  for (i=0; i<glo_psx_per_h5pdwrite.size; i++){
    json_array_append_new(ary_psx_per_h5pdwrite, json_integer(glo_psx_per_h5pdwrite.data[i]));
  }
  json_object_set_new(json_per_psx_stats, "posix write calls parallel", ary_psx_per_h5pdwrite); 

  double mean_psx_per_h5pdwrite = get_mean_ui(glo_psx_per_h5pdwrite.data, 
						glo_psx_per_h5pdwrite.size);
  double std_psx_per_h5pdwrite = get_std_ui(glo_psx_per_h5pdwrite.data, 
						glo_psx_per_h5pdwrite.size);
  
  json_object_set_new(json_per_psx_stats, "mean posix write calls parllel", 
						json_real(mean_psx_per_h5pdwrite));
  json_object_set_new(json_per_psx_stats, "std posix write calls parallel", 
						json_real(std_psx_per_h5pdwrite));
  

  /*write buff*/ 
  json_t* ary_psx_buff_per_h5dwrite = json_array();
  for (i=0; i<glo_psx_buff_per_h5dwrite.size; i++){
    json_array_append_new(ary_psx_buff_per_h5dwrite, json_integer(
				glo_psx_buff_per_h5dwrite.data[i]));
  }
  json_object_set_new(json_per_psx_stats, "posix write size", 
							ary_psx_buff_per_h5dwrite); 
   
  
  double mean_psx_buff_per_h5dwrite = get_mean_ull(glo_psx_buff_per_h5dwrite.data, 
						glo_psx_buff_per_h5dwrite.size);
  double std_psx_buff_per_h5dwrite = get_std_ull(glo_psx_buff_per_h5dwrite.data, 
						glo_psx_buff_per_h5dwrite.size);
  
  json_object_set_new(json_per_psx_stats, "mean posix write size", 
						json_real(mean_psx_buff_per_h5dwrite));
  json_object_set_new(json_per_psx_stats, "std posix write size", 
						json_real(std_psx_buff_per_h5dwrite));
  
  /*pwrite buff*/ 
  json_t* ary_psx_buff_per_h5pdwrite = json_array();
  for (i=0; i<glo_psx_buff_per_h5pdwrite.size; i++){
    json_array_append_new(ary_psx_buff_per_h5pdwrite, json_integer(
				glo_psx_buff_per_h5pdwrite.data[i]));
  }
  json_object_set_new(json_per_psx_stats, "posix write size parallel", 
							ary_psx_buff_per_h5pdwrite); 
   
  
  double mean_psx_buff_per_h5pdwrite = get_mean_ull(glo_psx_buff_per_h5pdwrite.data, 
						glo_psx_buff_per_h5pdwrite.size);
  double std_psx_buff_per_h5pdwrite = get_std_ull(glo_psx_buff_per_h5pdwrite.data, 
						glo_psx_buff_per_h5pdwrite.size);
  
  json_object_set_new(json_per_psx_stats, "mean posix write size parallel", 
						json_real(mean_psx_buff_per_h5pdwrite));
  json_object_set_new(json_per_psx_stats, "std posix write size parallel", 
						json_real(std_psx_buff_per_h5pdwrite));
 

  json_object_set_new(json_root, "posix per hdf5 stats", json_per_psx_stats);

   
  return ;
}


void reset_api_counts(struct h5_api_counts my_api_counts)
{
  my_api_counts.fcreate_count=0;
  my_api_counts.fopen_count=0;
  my_api_counts.fclose_count=0;
  my_api_counts.acreate_count=0;
  my_api_counts.aopen_count=0;
  my_api_counts.awrite_count=0;
  my_api_counts.aread_count=0;
  my_api_counts.aclose_count=0;
  my_api_counts.dcreate_count=0;
  my_api_counts.dopen_count=0;
  my_api_counts.dwrite_count=0;
  my_api_counts.dread_count=0;
  my_api_counts.dclose_count=0;
  my_api_counts.gcreate_count=0;
  my_api_counts.gopen_count=0;
  my_api_counts.gclose_count=0;
  return ;
}


void log_MPI_reduce()
{
  /* Parallel api counts */
  MPI_Reduce(&loc_parallel_api_counts.fopen_count, &glo_parallel_api_counts.fopen_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_parallel_api_counts.fcreate_count, &glo_parallel_api_counts.fcreate_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_parallel_api_counts.dread_count, &glo_parallel_api_counts.dread_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_parallel_api_counts.dwrite_count, &glo_parallel_api_counts.dwrite_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  /* Serial api counts */ 
  MPI_Reduce(&loc_serial_api_counts.fopen_count, &glo_serial_api_counts.fopen_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_serial_api_counts.fcreate_count, &glo_serial_api_counts.fcreate_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);

  MPI_Reduce(&loc_serial_api_counts.acreate_count, &glo_serial_api_counts.acreate_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_serial_api_counts.aopen_count, &glo_serial_api_counts.aopen_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_serial_api_counts.aread_count, &glo_serial_api_counts.aread_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_serial_api_counts.awrite_count, &glo_serial_api_counts.awrite_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  
  MPI_Reduce(&loc_serial_api_counts.dcreate_count, &glo_serial_api_counts.dcreate_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_serial_api_counts.dopen_count, &glo_serial_api_counts.dopen_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_serial_api_counts.dwrite_count, &glo_serial_api_counts.dwrite_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_serial_api_counts.dread_count, &glo_serial_api_counts.dread_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);

  MPI_Reduce(&loc_serial_api_counts.gopen_count, &glo_serial_api_counts.gopen_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_serial_api_counts.gcreate_count, &glo_serial_api_counts.gcreate_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
 
  MPI_Reduce(&loc_psx_cnts.write_count, &glo_psx_cnts.write_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_psx_cnts.read_count, &glo_psx_cnts.read_count, 
					1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
  /* Data Read/Write */
  MPI_Reduce(&loc_ph5_buff_sz.read, &glo_ph5_buff_sz.read, 1, MPI_LONG_LONG, MPI_SUM, 
							    0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_ph5_buff_sz.write, &glo_ph5_buff_sz.write, 1, MPI_LONG_LONG, MPI_SUM, 
							    0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_h5_buff_sz.read, &glo_h5_buff_sz.read, 1, MPI_LONG_LONG, MPI_SUM, 
							    0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_h5_buff_sz.write, &glo_h5_buff_sz.write, 1, MPI_LONG_LONG, MPI_SUM, 
							    0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_psx_buff_sz.read, &glo_psx_buff_sz.read, 1, MPI_LONG_LONG, MPI_SUM, 
							    0, MPI_COMM_WORLD);
  MPI_Reduce(&loc_psx_buff_sz.write, &glo_psx_buff_sz.write, 1, MPI_LONG_LONG, MPI_SUM, 
							    0, MPI_COMM_WORLD);
  return ;
}


void serial_reduce()
{
  glo_psx_cnts = loc_psx_cnts;
  glo_psx_buff_sz = loc_psx_buff_sz;
  glo_h5_buff_sz = loc_h5_buff_sz;
  glo_serial_api_counts = loc_serial_api_counts;
}


void serial_gather()
{
  glo_psx_per_h5dread = loc_psx_per_h5dread;
  glo_psx_per_h5dwrite = loc_psx_per_h5dwrite;
  glo_psx_buff_per_h5dread = loc_psx_buff_per_h5dread;
  glo_psx_buff_per_h5dwrite = loc_psx_buff_per_h5dwrite;
}

//TODO: atexit should be probably different
void log_atexit()
{
  extrct_job_info(&job_log);
  serial_reduce();
  serial_gather();
  crt_json_log();
  send_to_mods(json_root);
  /*int i;
  //fprintf(stderr, "Vector is being printed of size %d\n", loc_psx_per_h5dread.size);
  for (i=0; i<loc_psx_per_h5dread.size; i++){
    //fprintf(stderr, "%d\n", loc_psx_per_h5dread.data[i]);
  }*/
  return ;	
}

//FUTURE TODO: modularize this
void log_MPI_gather()
{
  int world_rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
  
  int i;
  /*POSIX reads per Dread*/
  //fprintf(stderr, "dread from rank %d is being printed of size %d\n", 
//				world_rank, loc_psx_per_h5dread.size);
  for (i=0; i<loc_psx_per_h5dread.size; i++){
    //fprintf(stderr, "%d\n", loc_psx_per_h5dread.data[i]);
  }
  int glo_h5Dread_count = 0;
  MPI_Reduce(&h5Dread_count, &glo_h5Dread_count, 1, MPI_INT, MPI_SUM, 
							    0, MPI_COMM_WORLD);
  uivector_init(&glo_psx_per_h5dread);
  if (world_rank == 0){
    //TODO: Handle case when the memory alloc fails
    uivector_resize(&glo_psx_per_h5dread, glo_h5Dread_count);
  }
  MPI_Gather(loc_psx_per_h5dread.data, loc_psx_per_h5dread.size, MPI_UNSIGNED, 
	glo_psx_per_h5dread.data,loc_psx_per_h5dread.size , MPI_UNSIGNED, 0, MPI_COMM_WORLD);
  if (world_rank == 0){
    //fprintf(stderr, "global H5Dread counts %d\n", glo_h5Dread_count);
    for (i=0; i<glo_h5Dread_count; i++){
      //fprintf(stderr, "%d\n", glo_psx_per_h5dread.data[i]);
    }
  }

  /*POSIX reads per pDread*/
  //fprintf(stderr, "pdread from rank %d is being printed of size %d\n", 
//				world_rank, loc_psx_per_h5pdread.size);
  for (i=0; i<loc_psx_per_h5pdread.size; i++){
    //fprintf(stderr, "%d\n", loc_psx_per_h5pdread.data[i]);
  }
  //int glo_h5pDread_count = 0;
  //MPI_Reduce(&h5pDread_count, &glo_h5pDread_count, 1, MPI_INT, MPI_SUM, 
	//						    0, MPI_COMM_WORLD);
  uivector_init(&glo_psx_per_h5pdread);
  if (world_rank == 0){
    //TODO: Handle case when the memory alloc fails
    uivector_resize(&glo_psx_per_h5pdread, h5pDread_count);
  }
  MPI_Reduce(loc_psx_per_h5pdread.data, glo_psx_per_h5pdread.data, loc_psx_per_h5pdread.size , 
						MPI_UNSIGNED, MPI_SUM, 0, MPI_COMM_WORLD);
  if (world_rank == 0){
    //fprintf(stderr, "H5pDread counts %d\n", h5pDread_count);
    for (i=0; i<h5pDread_count; i++){
      //fprintf(stderr, "%d\n", glo_psx_per_h5pdread.data[i]);
    }
  }
  
  /*POSIX writes per Dwrite*/
  //fprintf(stderr, "dwrite from rank %d is being printed of size %d\n", 
//				 world_rank, loc_psx_per_h5dwrite.size);
  for (i=0; i<loc_psx_per_h5dwrite.size; i++){
    //fprintf(stderr, "%d\n", loc_psx_per_h5dwrite.data[i]);
  }
  int glo_h5Dwrite_count = 0;
  MPI_Reduce(&h5Dwrite_count, &glo_h5Dwrite_count, 1, MPI_INT, MPI_SUM, 
							    0, MPI_COMM_WORLD);
  uivector_init(&glo_psx_per_h5dwrite);
  if (world_rank == 0){
    //TODO: Handle case when the memory alloc fails
    uivector_resize(&glo_psx_per_h5dwrite, glo_h5Dwrite_count);
  }
  MPI_Gather(loc_psx_per_h5dwrite.data, loc_psx_per_h5dwrite.size, MPI_UNSIGNED, 
	glo_psx_per_h5dwrite.data,loc_psx_per_h5dwrite.size , MPI_UNSIGNED, 0, MPI_COMM_WORLD);
  if (world_rank == 0){
    //fprintf(stderr, "global H5Dwrite counts %d\n", glo_h5Dwrite_count);
    for (i=0; i<glo_h5Dwrite_count; i++){
      //fprintf(stderr, "%d\n", glo_psx_per_h5dwrite.data[i]);
    }
  }

  /*POSIX writes per pDwrite*/
  //fprintf(stderr, "pdwrite from rank %d is being printed of size %d\n", 
//				 world_rank, loc_psx_per_h5pdwrite.size);
  for (i=0; i<loc_psx_per_h5pdwrite.size; i++){
    //fprintf(stderr, "%d\n", loc_psx_per_h5pdwrite.data[i]);
  }
  //int glo_h5pDwrite_count = 0;
  //MPI_Reduce(&h5pDwrite_count, &glo_h5pDwrite_count, 1, MPI_INT, MPI_SUM, 
	//						    0, MPI_COMM_WORLD);
  uivector_init(&glo_psx_per_h5pdwrite);
  if (world_rank == 0){
    //TODO: Handle case when the memory alloc fails
    uivector_resize(&glo_psx_per_h5pdwrite, h5pDwrite_count);
  }
  MPI_Reduce(loc_psx_per_h5pdwrite.data, glo_psx_per_h5pdwrite.data, loc_psx_per_h5pdwrite.size , 
							MPI_UNSIGNED, MPI_SUM, 0, MPI_COMM_WORLD);
  if (world_rank == 0){
    //fprintf(stderr, "global H5pDwrite counts %d\n", h5pDwrite_count);
    for (i=0; i<h5pDwrite_count; i++){
      //fprintf(stderr, "%d\n", glo_psx_per_h5pdwrite.data[i]);
    }
  }
  
  /*POSIX read buffer per Dread*/
  //fprintf(stderr, "dread buffer from rank %d is being printed of size %d\n", 
//				world_rank, loc_psx_buff_per_h5dread.size);
  for (i=0; i<loc_psx_buff_per_h5dread.size; i++){
    //fprintf(stderr, "%d\n", loc_psx_buff_per_h5dread.data[i]);
  }
  ullvector_init(&glo_psx_buff_per_h5dread);
  if (world_rank == 0){
    //TODO: Handle case when the memory alloc fails
    ullvector_resize(&glo_psx_buff_per_h5dread, glo_h5Dread_count);
  }
  MPI_Gather(loc_psx_buff_per_h5dread.data, loc_psx_buff_per_h5dread.size, 
			MPI_UNSIGNED_LONG_LONG, glo_psx_buff_per_h5dread.data,
			loc_psx_buff_per_h5dread.size, MPI_UNSIGNED_LONG_LONG, 
							   0, MPI_COMM_WORLD);
  if (world_rank == 0){
    //fprintf(stderr, "global H5Dread buffer size %d\n", glo_h5Dread_count);
    for (i=0; i<glo_h5Dread_count; i++){
      //fprintf(stderr, "%d\n", glo_psx_buff_per_h5dread.data[i]);
    }
  }

  /*POSIX read buffer per pDread*/
  //fprintf(stderr, "pdread buffer from rank %d is being printed of size %d\n", 
//				world_rank, loc_psx_buff_per_h5pdread.size);
  for (i=0; i<loc_psx_buff_per_h5pdread.size; i++){
    //fprintf(stderr, "%d\n", loc_psx_buff_per_h5pdread.data[i]);
  }
  ullvector_init(&glo_psx_buff_per_h5pdread);
  if (world_rank == 0){
    //TODO: Handle case when the memory alloc fails
    ullvector_resize(&glo_psx_buff_per_h5pdread, h5pDread_count);
  }
  MPI_Reduce(loc_psx_buff_per_h5pdread.data, glo_psx_buff_per_h5pdread.data,
			loc_psx_buff_per_h5pdread.size, MPI_UNSIGNED_LONG_LONG,
						MPI_SUM, 0, MPI_COMM_WORLD);
  if (world_rank == 0){
    //fprintf(stderr, "global H5pDread buffer size %d\n", h5pDread_count);
    for (i=0; i<h5pDread_count; i++){
      //fprintf(stderr, "%d\n", glo_psx_buff_per_h5pdread.data[i]);
    }
  }

 
  /*POSIX write buffer per Dwrite*/
  //fprintf(stderr, "dwrite buffer from rank %d is being printed of size %d\n", 
//				world_rank, loc_psx_buff_per_h5dwrite.size);
  for (i=0; i<loc_psx_buff_per_h5dwrite.size; i++){
    //fprintf(stderr, "%d\n", loc_psx_buff_per_h5dwrite.data[i]);
  }
  ullvector_init(&glo_psx_buff_per_h5dwrite);
  if (world_rank == 0){
    //TODO: Handle case when the memory alloc fails
    ullvector_resize(&glo_psx_buff_per_h5dwrite, glo_h5Dwrite_count);
  }
  MPI_Gather(loc_psx_buff_per_h5dwrite.data, loc_psx_buff_per_h5dwrite.size, 
		     MPI_UNSIGNED_LONG_LONG, glo_psx_buff_per_h5dwrite.data,
    		      loc_psx_buff_per_h5dwrite.size, MPI_UNSIGNED_LONG_LONG, 
							  0, MPI_COMM_WORLD);
  if (world_rank == 0){
    //fprintf(stderr, "global H5Dwrite buffer size %d\n", glo_h5Dwrite_count);
    for (i=0; i<glo_h5Dwrite_count; i++){
      //fprintf(stderr, "%d\n", glo_psx_buff_per_h5dwrite.data[i]);
    }
  }

  /*POSIX write buffer per pDwrite*/
  //fprintf(stderr, "pdwrite buffer from rank %d is being printed of size %d\n", 
//				world_rank, loc_psx_buff_per_h5pdwrite.size);
  for (i=0; i<loc_psx_buff_per_h5pdwrite.size; i++){
    //fprintf(stderr, "%d\n", loc_psx_buff_per_h5pdwrite.data[i]);
  }
  ullvector_init(&glo_psx_buff_per_h5pdwrite);
  if (world_rank == 0){
    //TODO: Handle case when the memory alloc fails
    ullvector_resize(&glo_psx_buff_per_h5pdwrite, h5pDwrite_count);
  }
  MPI_Reduce(loc_psx_buff_per_h5pdwrite.data, glo_psx_buff_per_h5pdwrite.data, 
			loc_psx_buff_per_h5pdwrite.size, MPI_UNSIGNED_LONG_LONG, 
						  MPI_SUM, 0, MPI_COMM_WORLD);
  if (world_rank == 0){
    //fprintf(stderr, "global H5pDwrite buffer size %d\n", h5pDwrite_count);
    for (i=0; i<h5pDwrite_count; i++){
      //fprintf(stderr, "%d\n", glo_psx_buff_per_h5pdwrite.data[i]);
    }
  }

}


void mpi_finalize_cb()
{
  MPI_Comm comm = MPI_COMM_WORLD;
  /* Reduce operations */
  log_MPI_reduce();
  log_MPI_gather();

  int world_rank;
  MPI_Comm_rank(comm, &world_rank);
  if (world_rank == 0)
  {
    extrct_job_info(&job_log);
    crt_json_log();
    send_to_mods(json_root);
  }
  /* Clean up */
  
  /* To reset counters and free memory */
  glo_ph5_buff_sz.read = 0;
  glo_ph5_buff_sz.write = 0;
  loc_ph5_buff_sz.read = 0; 
  loc_ph5_buff_sz.write = 0;

  reset_api_counts(loc_parallel_api_counts);
  reset_api_counts(glo_parallel_api_counts); 
  reset_job_log();  
  return ;	
}


/***************************/
/* User wrappers start here */
/***************************/
/* Determines if the the api call is collective */
hbool_t is_mpi(hid_t fapl_id)
{
  hbool_t have_mpi = false;
  hid_t driver_id;
  // If its the default fapl then we know its serial
  if (fapl_id == H5P_DEFAULT){
    have_mpi = false;
  }
  else if((driver_id = H5Pget_driver(fapl_id)) > 0 && driver_id == H5FD_MPIO){
    have_mpi = true;
  }
  return have_mpi;
}

/* Determines if the Dread/Dwrite are collective */
hbool_t is_mpi_D(hid_t plist_id)
{
  hbool_t have_mpi = false;
  H5FD_mpio_xfer_t xfer_mode = H5FD_MPIO_INDEPENDENT;
  if (plist_id == H5P_DEFAULT){
    have_mpi = false;
  }
  else{
    H5Pget_dxpl_mpio(plist_id, &xfer_mode);
    if(xfer_mode == H5FD_MPIO_INDEPENDENT)
      have_mpi = false;
    else 
      have_mpi = true;
  }
  return have_mpi;
}

/* Gets the datasize written/read */
hsize_t get_dataset_size(hid_t dset, hid_t mem_type_id, hid_t mem_space_id)
{
  hsize_t r_size;
  hid_t space_id = H5Dget_space((hid_t)dset);  
  if(H5S_ALL == mem_space_id)
    r_size = H5Tget_size(mem_type_id) * (hsize_t)H5Sget_simple_extent_npoints(space_id);
  else
    r_size = H5Tget_size(mem_type_id) * (hsize_t)H5Sget_select_npoints(mem_space_id); 
  return r_size; 
}


void write_mywrap(int fd, const void *buf, size_t count)
{
  loc_psx_cnts.write_count++;
  loc_psx_buff_sz.write+=(long long)count;
  if (flag_h5dwrite>0){
    loc_psx_per_h5dwrite.data[h5Dwrite_count-1]++;
    loc_psx_buff_per_h5dwrite.data[h5Dwrite_count-1]+=(unsigned long long)count;
  }
  if (flag_h5pdwrite>0){
    loc_psx_per_h5pdwrite.data[h5pDwrite_count-1]++;
    loc_psx_buff_per_h5pdwrite.data[h5pDwrite_count-1]+=(unsigned long long)count;
  }
  return ;
}


void read_mywrap(int fd, void *buf, size_t count)
{
  loc_psx_cnts.read_count++;
  loc_psx_buff_sz.read+=(long long)count;
  /*There might be some reads not called from H5Dread*/
  if (flag_h5dread>0){
    loc_psx_per_h5dread.data[h5Dread_count-1]++;
    loc_psx_buff_per_h5dread.data[h5Dread_count-1]+=(unsigned long long)count;
    //fprintf(stderr, "%d posix reading %d\n", h5Dread_count,count);
  }
  if (flag_h5pdread>0){
    loc_psx_per_h5pdread.data[h5pDread_count-1]++;
    loc_psx_buff_per_h5pdread.data[h5pDread_count-1]+=(unsigned long long)count;
    //fprintf(stderr, "%d pparallel osix reading %d\n", h5pDread_count,count);
  }
  return ;
}


void H5Fcreate_mywrap(const char *name, unsigned flags, hid_t fcpl_id, hid_t fapl_id)
{
  if (is_mpi(fapl_id)){
    loc_parallel_api_counts.fcreate_count++;
  }
  else{
    loc_serial_api_counts.fcreate_count++;
  }
  return ;
}


void H5Fopen_mywrap(const char *name, unsigned flags, hid_t fapl_id)
{
  if (is_mpi(fapl_id)){
    loc_parallel_api_counts.fopen_count++;
  }
  else{
    loc_serial_api_counts.fopen_count++;
  } 
  return ;
}

/* Assumes serial */
void H5Fclose_mywrap(hid_t attr_id)
{
  loc_serial_api_counts.fclose_count++;
  return ;
}

/* Assumes serial */
void H5Acreate2_mywrap(hid_t loc_id, const char *attr_name, hid_t type_id, hid_t 
					space_id, hid_t acpl_id, hid_t aapl_id)
{
  loc_serial_api_counts.acreate_count++;
  return ;
}

/* Assumes serial */
void H5Aopen_mywrap(hid_t obj_id, const char *attr_name, hid_t aapl_id)
{
  loc_serial_api_counts.aopen_count++;
  return ;
}

/* Assumes serial */
void H5Awrite_mywrap(hid_t attr_id, hid_t mem_type_id, const void *buf)
{
  loc_serial_api_counts.awrite_count++;
  return ;
}

/* Assumes serial */
void H5Aread_mywrap(hid_t attr_id, hid_t mem_type_id, void *buf)
{
  loc_serial_api_counts.aread_count++;
  return ;
}

/* Assumes serial */
void H5Aclose_mywrap(hid_t attr_id)
{
  loc_serial_api_counts.aclose_count++;
  return ;
}

/* Assumes serial */
void H5Dcreate2_mywrap(hid_t loc_id, const char *name, hid_t dtype_id, hid_t space_id,
					 hid_t lcpl_id, hid_t dcpl_id, hid_t dapl_id)
{
  loc_serial_api_counts.dcreate_count++;
  return ;
}


/* Assumes serial */
void H5Dopen2_mywrap(const char *name, unsigned flags, hid_t dapl_id)
{
  loc_serial_api_counts.dopen_count++;
  return ;
}


void H5Dwrite_mywrap(hid_t dataset_id, hid_t mem_type_id, hid_t mem_space_id, 
		  hid_t file_space_id, hid_t xfer_plist_id, const void * buf)
{
  hsize_t dwrite_size = get_dataset_size(dataset_id, mem_type_id, mem_space_id);
  if (is_mpi_D(xfer_plist_id)){
    loc_parallel_api_counts.dwrite_count++;
    loc_ph5_buff_sz.write += dwrite_size;
    //TODO: Need to do univector initialize
    //uivector_reserve(&loc_psx_per_h5dwrite, sizeof(unsigned int)*10);
    uivector_push_back(&loc_psx_per_h5pdwrite, 0);
    ullvector_push_back(&loc_psx_buff_per_h5pdwrite, (unsigned long long)0);
    flag_h5pdwrite=1;
    h5pDwrite_count++;
  }
  else{
    loc_serial_api_counts.dwrite_count++;
    loc_h5_buff_sz.write += dwrite_size;
    //TODO: Need to do univector initialize
    //uivector_reserve(&loc_psx_per_h5dwrite, sizeof(unsigned int)*10);
    uivector_push_back(&loc_psx_per_h5dwrite, 0);
    ullvector_push_back(&loc_psx_buff_per_h5dwrite, (unsigned long long)0);
    flag_h5dwrite=1;
    h5Dwrite_count++;
  }
  return ;
}


void H5Dread_mywrap(hid_t dataset_id, hid_t mem_type_id, hid_t mem_space_id, 
			hid_t file_space_id, hid_t xfer_plist_id, void * buf)
{
  hsize_t dread_size = get_dataset_size(dataset_id, mem_type_id, mem_space_id);
  if (is_mpi_D(xfer_plist_id)){
    loc_parallel_api_counts.dread_count++;
    loc_ph5_buff_sz.read += dread_size;
    //uivector_reserve(&loc_psx_per_h5dread, sizeof(unsigned int)*10);
    //fprintf(stderr, "dread reading %d\n", dread_size);
    uivector_push_back(&loc_psx_per_h5pdread, 0);
    ullvector_push_back(&loc_psx_buff_per_h5pdread, (unsigned long long)0);
    flag_h5pdread=1;
    h5pDread_count++;
  }
  else{
    loc_serial_api_counts.dread_count++;
    loc_h5_buff_sz.read += dread_size;
    //uivector_reserve(&loc_psx_per_h5dread, sizeof(unsigned int)*10);
    //fprintf(stderr, "dread reading %d\n", dread_size);
    uivector_push_back(&loc_psx_per_h5dread, 0);
    ullvector_push_back(&loc_psx_buff_per_h5dread, (unsigned long long)0);
    flag_h5dread=1;
    h5Dread_count++;
  }
  return ;
}


void H5Dclose_mywrap(hid_t dataset_id)
{
  loc_serial_api_counts.dclose_count++;
  return ;
}

/* Assumes serial */
void H5Gcreate2_mywrap(hid_t loc_id, const char *name, hid_t lcpl_id, hid_t gcpl_id, hid_t gapl_id)
{
  loc_serial_api_counts.gcreate_count++;
  return ;
}

/* Assumes serial */
void H5Gopen2_mywrap(hid_t loc_id, const char * name, hid_t gapl_id)
{
  loc_serial_api_counts.aopen_count++;
  return ;
}

/* Assumes serial */
void H5Gclose_mywrap(hid_t group_id)
{
  loc_serial_api_counts.aclose_count++;
  return ;
}

void H5Lcopy_mywrap(hid_t src_loc_id, const char *src_name, hid_t dest_loc_id, const char *dest_name, hid_t lcpl_id, hid_t lapl_id )
{
  meta_api_count++;
  return ;
}

void H5Lcreate_external_mywrap( const char *target_file_name, const char *target_obj_name, hid_t link_loc_id, const char *link_name, hid_t lcpl_id, hid_t lapl_id )
{
  meta_api_count++;
  return ;
}

void H5Lcreate_soft_mywrap( const char *target_path, hid_t link_loc_id, const char *link_name, hid_t lcpl_id, hid_t lapl_id )
{
  meta_api_count++;
  return ;
}

void H5Lcreate_hard_mywrap( hid_t obj_loc_id, const char *obj_name, hid_t link_loc_id, const char *link_name, hid_t lcpl_id, hid_t lapl_id )
{
  meta_api_count++;
  return ;
}

void H5Ldelete_mywrap( hid_t loc_id, const char *name, hid_t lapl_id )
{
  meta_api_count++;
  return ;
}

void H5Ldelete_by_idx_mywrap( hid_t loc_id, const char *group_name, H5_index_t index_field, H5_iter_order_t order, hsize_t n, hid_t lapl_id )
{
  meta_api_count++;
  return ;
}

void H5Lmove_mywrap( hid_t src_loc_id, const char *src_name, hid_t dest_loc_id, const char *dest_name, hid_t lcpl_id, hid_t lapl_id )
{
  meta_api_count++;
  return ;
}

void H5Ocopy_mywrap( hid_t src_loc_id, const char *src_name, hid_t dst_loc_id, const char *dst_name, hid_t ocpypl_id, hid_t lcpl_id )
{
  meta_api_count++;
  return ;
}

void H5Odecr_refcount_mywrap( hid_t object_id )
{
  meta_api_count++;
  return ;
}

void H5Oincr_refcount_mywrap( hid_t object_id )
{
  meta_api_count++;
  return ;
}

void H5Olink_mywrap( hid_t object_id, hid_t new_loc_id, const char *new_link_name, hid_t lcpl, hid_t lapl )
{
  meta_api_count++;
  return ;
}

void H5Oset_comment_mywrap( hid_t object_id, const char *comment )
{
  meta_api_count++;
  return ;
}

void H5Oset_comment_by_name_mywrap( hid_t loc_id, const char *name, const char *comment, hid_t lapl_id )
{
  meta_api_count++;
  return ;
}

void H5Oopen_mywrap( hid_t loc_id, const char *name, hid_t lapl_id )
{
  meta_api_count++;
  return ;
}

void H5Oclose_mywrap( hid_t object_id )
{
  meta_api_count++;
  return ;
}

void H5Rcreate_mywrap( void *ref, hid_t loc_id, const char *name, H5R_type_t ref_type, hid_t space_id )
{
  meta_api_count++;
  return ;
}

void H5Rdereference_mywrap( hid_t loc_id, H5R_type_t ref_type, void *ref )
{
  meta_api_count++;
  return ;
}




