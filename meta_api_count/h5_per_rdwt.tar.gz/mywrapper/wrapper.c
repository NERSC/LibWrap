#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "gotcha/gotcha.h"
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/* User included headers*/
#include <hdf5.h>

#include "log_init.h"
#include "h5_wrap.h"

#define NFUNCS 18


pthread_mutex_t log_mutex;

static gotcha_wrappee_handle_t H5Fcreate_handle;
typedef hid_t (*H5Fcreate_fptr)(const char *name, unsigned flags, hid_t fcpl_id, hid_t fapl_id);

hid_t __real_H5Fcreate(const char *name, unsigned flags, hid_t fcpl_id, hid_t fapl_id);

static gotcha_wrappee_handle_t H5Fopen_handle;
typedef hid_t (*H5Fopen_fptr)( const char *name, unsigned flags, hid_t fapl_id );

hid_t __real_H5Fopen( const char *name, unsigned flags, hid_t fapl_id );

static gotcha_wrappee_handle_t H5Fclose_handle;
typedef herr_t (*H5Fclose_fptr)(hid_t file_id);

herr_t __real_H5Fclose(hid_t file_id);

static gotcha_wrappee_handle_t H5Acreate2_handle;
typedef hid_t (*H5Acreate2_fptr)(hid_t loc_id, const char *attr_name, hid_t type_id, hid_t space_id, hid_t acpl_id, hid_t aapl_id);

hid_t __real_H5Acreate2(hid_t loc_id, const char *attr_name, hid_t type_id, hid_t space_id, hid_t acpl_id, hid_t aapl_id);

static gotcha_wrappee_handle_t H5Aopen_handle;
typedef hid_t (*H5Aopen_fptr)(hid_t obj_id, const char *attr_name, hid_t aapl_id);

hid_t __real_H5Aopen(hid_t obj_id, const char *attr_name, hid_t aapl_id);

static gotcha_wrappee_handle_t H5Awrite_handle;
typedef herr_t (*H5Awrite_fptr)(hid_t attr_id, hid_t mem_type_id, const void *buf);

herr_t __real_H5Awrite(hid_t attr_id, hid_t mem_type_id, const void *buf);

static gotcha_wrappee_handle_t H5Aread_handle;
typedef herr_t (*H5Aread_fptr)(hid_t attr_id, hid_t mem_type_id, void *buf);

herr_t __real_H5Aread(hid_t attr_id, hid_t mem_type_id, void *buf);

static gotcha_wrappee_handle_t H5Aclose_handle;
typedef herr_t (*H5Aclose_fptr)(hid_t attr_id);

herr_t __real_H5Aclose(hid_t attr_id);

static gotcha_wrappee_handle_t H5Dcreate2_handle;
typedef hid_t (*H5Dcreate2_fptr)(hid_t loc_id, const char *name, hid_t dtype_id, hid_t space_id, hid_t lcpl_id, hid_t dcpl_id, hid_t dapl_id);

hid_t __real_H5Dcreate2(hid_t loc_id, const char *name, hid_t dtype_id, hid_t space_id, hid_t lcpl_id, hid_t dcpl_id, hid_t dapl_id);

static gotcha_wrappee_handle_t H5Dopen2_handle;
typedef hid_t (*H5Dopen2_fptr)(hid_t loc_id, const char *name, hid_t dapl_id);

hid_t __real_H5Dopen2(hid_t loc_id, const char *name, hid_t dapl_id);

static gotcha_wrappee_handle_t H5Dwrite_handle;
typedef herr_t (*H5Dwrite_fptr)(hid_t dataset_id, hid_t mem_type_id, hid_t mem_space_id, hid_t file_space_id, hid_t xfer_plist_id, const void *buf);

herr_t __real_H5Dwrite(hid_t dataset_id, hid_t mem_type_id, hid_t mem_space_id, hid_t file_space_id, hid_t xfer_plist_id, const void *buf);

static gotcha_wrappee_handle_t H5Dread_handle;
typedef herr_t (*H5Dread_fptr)(hid_t dataset_id, hid_t mem_type_id, hid_t mem_space_id, hid_t file_space_id, hid_t xfer_plist_id, void *buf);

herr_t __real_H5Dread(hid_t dataset_id, hid_t mem_type_id, hid_t mem_space_id, hid_t file_space_id, hid_t xfer_plist_id, void *buf);

static gotcha_wrappee_handle_t H5Dclose_handle;
typedef herr_t (*H5Dclose_fptr)(hid_t dataset_id);

herr_t __real_H5Dclose(hid_t dataset_id);

static gotcha_wrappee_handle_t H5Gcreate2_handle;
typedef hid_t (*H5Gcreate2_fptr)(hid_t loc_id, const char *name, hid_t lcpl_id, hid_t gcpl_id, hid_t gapl_id);

hid_t __real_H5Gcreate2(hid_t loc_id, const char *name, hid_t lcpl_id, hid_t gcpl_id, hid_t gapl_id);

static gotcha_wrappee_handle_t H5Gopen2_handle;
typedef hid_t (*H5Gopen2_fptr)(hid_t loc_id, const char *name, hid_t gapl_id);

hid_t __real_H5Gopen2(hid_t loc_id, const char *name, hid_t gapl_id);

static gotcha_wrappee_handle_t H5Gclose_handle;
typedef herr_t (*H5Gclose_fptr)(hid_t group_id);

herr_t __real_H5Gclose(hid_t group_id);

static gotcha_wrappee_handle_t write_handle;
typedef ssize_t (*write_fptr)(int fd, const void *buf, size_t count);

ssize_t __real_write(int fd, const void *buf, size_t count);

static gotcha_wrappee_handle_t read_handle;
typedef ssize_t (*read_fptr)(int fd, void *buf, size_t count);

ssize_t __real_read(int fd, void *buf, size_t count);



hid_t __wrap_H5Fcreate(const char *name, unsigned flags, hid_t fcpl_id, hid_t fapl_id){

	hid_t result=__real_H5Fcreate(name, flags, fcpl_id, fapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Fcreate_mywrap(name, flags, fcpl_id, fapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static hid_t H5Fcreate_wrapper(const char *name, unsigned flags, hid_t fcpl_id, hid_t fapl_id){

	H5Fcreate_fptr H5Fcreate_wrappee = (H5Fcreate_fptr)gotcha_get_wrappee(H5Fcreate_handle);

	hid_t result=H5Fcreate_wrappee(name, flags, fcpl_id, fapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Fcreate_mywrap(name, flags, fcpl_id, fapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


hid_t __wrap_H5Fopen( const char *name, unsigned flags, hid_t fapl_id ){

	hid_t result=__real_H5Fopen(name, flags, fapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Fopen_mywrap(name, flags, fapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static hid_t H5Fopen_wrapper( const char *name, unsigned flags, hid_t fapl_id ){

	H5Fopen_fptr H5Fopen_wrappee = (H5Fopen_fptr)gotcha_get_wrappee(H5Fopen_handle);

	hid_t result=H5Fopen_wrappee(name, flags, fapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Fopen_mywrap(name, flags, fapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


herr_t __wrap_H5Fclose(hid_t file_id){

	herr_t result=__real_H5Fclose(file_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Fclose_mywrap(file_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static herr_t H5Fclose_wrapper(hid_t file_id){

	H5Fclose_fptr H5Fclose_wrappee = (H5Fclose_fptr)gotcha_get_wrappee(H5Fclose_handle);

	herr_t result=H5Fclose_wrappee(file_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Fclose_mywrap(file_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


hid_t __wrap_H5Acreate2(hid_t loc_id, const char *attr_name, hid_t type_id, hid_t space_id, hid_t acpl_id, hid_t aapl_id){

	hid_t result=__real_H5Acreate2(loc_id, attr_name, type_id, space_id, acpl_id, aapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Acreate2_mywrap(loc_id, attr_name, type_id, space_id, acpl_id, aapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static hid_t H5Acreate2_wrapper(hid_t loc_id, const char *attr_name, hid_t type_id, hid_t space_id, hid_t acpl_id, hid_t aapl_id){

	H5Acreate2_fptr H5Acreate2_wrappee = (H5Acreate2_fptr)gotcha_get_wrappee(H5Acreate2_handle);

	hid_t result=H5Acreate2_wrappee(loc_id, attr_name, type_id, space_id, acpl_id, aapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Acreate2_mywrap(loc_id, attr_name, type_id, space_id, acpl_id, aapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


hid_t __wrap_H5Aopen(hid_t obj_id, const char *attr_name, hid_t aapl_id){

	hid_t result=__real_H5Aopen(obj_id, attr_name, aapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Aopen_mywrap (obj_id, attr_name, aapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static hid_t H5Aopen_wrapper(hid_t obj_id, const char *attr_name, hid_t aapl_id){

	H5Aopen_fptr H5Aopen_wrappee = (H5Aopen_fptr)gotcha_get_wrappee(H5Aopen_handle);

	hid_t result=H5Aopen_wrappee(obj_id, attr_name, aapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Aopen_mywrap (obj_id, attr_name, aapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


herr_t __wrap_H5Awrite(hid_t attr_id, hid_t mem_type_id, const void *buf){

	herr_t result=__real_H5Awrite(attr_id, mem_type_id, buf);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Awrite_mywrap(attr_id, mem_type_id, buf);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static herr_t H5Awrite_wrapper(hid_t attr_id, hid_t mem_type_id, const void *buf){

	H5Awrite_fptr H5Awrite_wrappee = (H5Awrite_fptr)gotcha_get_wrappee(H5Awrite_handle);

	herr_t result=H5Awrite_wrappee(attr_id, mem_type_id, buf);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Awrite_mywrap(attr_id, mem_type_id, buf);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


herr_t __wrap_H5Aread(hid_t attr_id, hid_t mem_type_id, void *buf){

	herr_t result=__real_H5Aread(attr_id, mem_type_id, buf);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Aread_mywrap(attr_id, mem_type_id, buf);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static herr_t H5Aread_wrapper(hid_t attr_id, hid_t mem_type_id, void *buf){

	H5Aread_fptr H5Aread_wrappee = (H5Aread_fptr)gotcha_get_wrappee(H5Aread_handle);

	herr_t result=H5Aread_wrappee(attr_id, mem_type_id, buf);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Aread_mywrap(attr_id, mem_type_id, buf);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


herr_t __wrap_H5Aclose(hid_t attr_id){

	herr_t result=__real_H5Aclose(attr_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Aclose_mywrap(attr_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static herr_t H5Aclose_wrapper(hid_t attr_id){

	H5Aclose_fptr H5Aclose_wrappee = (H5Aclose_fptr)gotcha_get_wrappee(H5Aclose_handle);

	herr_t result=H5Aclose_wrappee(attr_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Aclose_mywrap(attr_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


hid_t __wrap_H5Dcreate2(hid_t loc_id, const char *name, hid_t dtype_id, hid_t space_id, hid_t lcpl_id, hid_t dcpl_id, hid_t dapl_id){

	hid_t result=__real_H5Dcreate2(loc_id, name, dtype_id, space_id, lcpl_id, dcpl_id, dapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Dcreate2_mywrap(loc_id, name, dtype_id, space_id, lcpl_id, dcpl_id, dapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static hid_t H5Dcreate2_wrapper(hid_t loc_id, const char *name, hid_t dtype_id, hid_t space_id, hid_t lcpl_id, hid_t dcpl_id, hid_t dapl_id){

	H5Dcreate2_fptr H5Dcreate2_wrappee = (H5Dcreate2_fptr)gotcha_get_wrappee(H5Dcreate2_handle);

	hid_t result=H5Dcreate2_wrappee(loc_id, name, dtype_id, space_id, lcpl_id, dcpl_id, dapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Dcreate2_mywrap(loc_id, name, dtype_id, space_id, lcpl_id, dcpl_id, dapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


hid_t __wrap_H5Dopen2(hid_t loc_id, const char *name, hid_t dapl_id){

	hid_t result=__real_H5Dopen2(loc_id, name, dapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Dopen2_mywrap(loc_id, name, dapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static hid_t H5Dopen2_wrapper(hid_t loc_id, const char *name, hid_t dapl_id){

	H5Dopen2_fptr H5Dopen2_wrappee = (H5Dopen2_fptr)gotcha_get_wrappee(H5Dopen2_handle);

	hid_t result=H5Dopen2_wrappee(loc_id, name, dapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Dopen2_mywrap(loc_id, name, dapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


herr_t __wrap_H5Dwrite(hid_t dataset_id, hid_t mem_type_id, hid_t mem_space_id, hid_t file_space_id, hid_t xfer_plist_id, const void *buf){

	herr_t result=__real_H5Dwrite(dataset_id, mem_type_id, mem_space_id, file_space_id, xfer_plist_id, buf);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Dwrite_mywrap(dataset_id, mem_type_id, mem_space_id, file_space_id, xfer_plist_id, buf);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static herr_t H5Dwrite_wrapper(hid_t dataset_id, hid_t mem_type_id, hid_t mem_space_id, hid_t file_space_id, hid_t xfer_plist_id, const void *buf){

	H5Dwrite_fptr H5Dwrite_wrappee = (H5Dwrite_fptr)gotcha_get_wrappee(H5Dwrite_handle);
	//fprintf(stderr, "%s\n", __func__);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Dwrite_mywrap(dataset_id, mem_type_id, mem_space_id, file_space_id, xfer_plist_id, buf);
	pthread_mutex_unlock(&log_mutex);

	herr_t result=H5Dwrite_wrappee(dataset_id, mem_type_id, mem_space_id, file_space_id, xfer_plist_id, buf);
	flag_h5dwrite = 0;
	flag_h5pdwrite = 0;
	return result;
}


herr_t __wrap_H5Dread(hid_t dataset_id, hid_t mem_type_id, hid_t mem_space_id, hid_t file_space_id, hid_t xfer_plist_id, void *buf){

	herr_t result=__real_H5Dread(dataset_id, mem_type_id, mem_space_id, file_space_id, xfer_plist_id, buf);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Dread_mywrap(dataset_id, mem_type_id, mem_space_id, file_space_id, xfer_plist_id, buf);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static herr_t H5Dread_wrapper(hid_t dataset_id, hid_t mem_type_id, hid_t mem_space_id, hid_t file_space_id, hid_t xfer_plist_id, void *buf){

	H5Dread_fptr H5Dread_wrappee = (H5Dread_fptr)gotcha_get_wrappee(H5Dread_handle);
	//fprintf(stderr, "%s\n", __func__);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Dread_mywrap(dataset_id, mem_type_id, mem_space_id, file_space_id, xfer_plist_id, buf);
	pthread_mutex_unlock(&log_mutex);

	herr_t result=H5Dread_wrappee(dataset_id, mem_type_id, mem_space_id, file_space_id, xfer_plist_id, buf);
	flag_h5dread = 0;
	flag_h5pdread = 0;
	return result;
}


herr_t __wrap_H5Dclose(hid_t dataset_id){

	herr_t result=__real_H5Dclose(dataset_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Dclose_mywrap(dataset_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static herr_t H5Dclose_wrapper(hid_t dataset_id){

	H5Dclose_fptr H5Dclose_wrappee = (H5Dclose_fptr)gotcha_get_wrappee(H5Dclose_handle);

	herr_t result=H5Dclose_wrappee(dataset_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Dclose_mywrap(dataset_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


hid_t __wrap_H5Gcreate2(hid_t loc_id, const char *name, hid_t lcpl_id, hid_t gcpl_id, hid_t gapl_id){

	hid_t result=__real_H5Gcreate2(loc_id, name, lcpl_id, gcpl_id, gapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Gcreate2_mywrap(loc_id, name, lcpl_id, gcpl_id, gapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static hid_t H5Gcreate2_wrapper(hid_t loc_id, const char *name, hid_t lcpl_id, hid_t gcpl_id, hid_t gapl_id){

	H5Gcreate2_fptr H5Gcreate2_wrappee = (H5Gcreate2_fptr)gotcha_get_wrappee(H5Gcreate2_handle);

	hid_t result=H5Gcreate2_wrappee(loc_id, name, lcpl_id, gcpl_id, gapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Gcreate2_mywrap(loc_id, name, lcpl_id, gcpl_id, gapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


hid_t __wrap_H5Gopen2(hid_t loc_id, const char *name, hid_t gapl_id){

	hid_t result=__real_H5Gopen2(loc_id, name, gapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Gopen2_mywrap(loc_id, name, gapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static hid_t H5Gopen2_wrapper(hid_t loc_id, const char *name, hid_t gapl_id){

	H5Gopen2_fptr H5Gopen2_wrappee = (H5Gopen2_fptr)gotcha_get_wrappee(H5Gopen2_handle);

	hid_t result=H5Gopen2_wrappee(loc_id, name, gapl_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Gopen2_mywrap(loc_id, name, gapl_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


herr_t __wrap_H5Gclose(hid_t group_id){

	herr_t result=__real_H5Gclose(group_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Gclose_mywrap(group_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static herr_t H5Gclose_wrapper(hid_t group_id){

	H5Gclose_fptr H5Gclose_wrappee = (H5Gclose_fptr)gotcha_get_wrappee(H5Gclose_handle);

	herr_t result=H5Gclose_wrappee(group_id);

	pthread_mutex_lock(&log_mutex);
	_log_init();
	H5Gclose_mywrap(group_id);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


ssize_t __wrap_write(int fd, const void *buf, size_t count){

	ssize_t result=__real_write(fd, buf, count);

	pthread_mutex_lock(&log_mutex);
	//_log_init();
	write_mywrap(fd, buf, count);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static ssize_t write_wrapper(int fd, const void *buf, size_t count){

	write_fptr write_wrappee = (write_fptr)gotcha_get_wrappee(write_handle);

	ssize_t result=write_wrappee(fd, buf, count);

	pthread_mutex_lock(&log_mutex);
	//_log_init();
	write_mywrap(fd, buf, count);
	pthread_mutex_unlock(&log_mutex);
	
	//fprintf(stderr, "%s: from the write return %d\n", __func__, result);
	return result;
}


ssize_t __wrap_read(int fd, void *buf, size_t count){

	ssize_t result=__real_read(fd, buf, count);

	pthread_mutex_lock(&log_mutex);
	//_log_init();
	read_mywrap(fd, buf, count);
	pthread_mutex_unlock(&log_mutex);

	return result;
}


static ssize_t read_wrapper(int fd, void *buf, size_t count){

	read_fptr read_wrappee = (read_fptr)gotcha_get_wrappee(read_handle);

	ssize_t result=read_wrappee(fd, buf, count);

	pthread_mutex_lock(&log_mutex);
	//_log_init();
	read_mywrap(fd, buf, count);
	pthread_mutex_unlock(&log_mutex);
	//fprintf(stderr, "%s: from the read return %d\n",__func__,result);
	return result;
}

/* Obtain a backtrace and print it to stdout. */
int print_trace (void)
{
  void *array[20];
  size_t size;
  char **strings;
  size_t i;
  int is_slurm = 0; 
  size = backtrace (array, 20);
  strings = backtrace_symbols (array, size);
   
  //fprintf (stderr, "Obtained %zd stack frames.\n", size);
   
  for (i = 0; i < size; i++)
     fprintf (stderr, "%s\n", strings[i]);
  /*
  fprintf(stderr, "%s %lu\n", __func__, __LINE__); 
  if (size>0){
  	fprintf(stderr, "length = %d and %s\n", strlen(strings[size-1]), strings[size-1]);
  }*/
  if (size>0 && strstr(strings[size-1], "srun")!=NULL){
    is_slurm = 1;
  }
  else{
    is_slurm = 0;
  }
  fprintf(stderr, "is_slurm = %d\n", is_slurm); 
  
  return is_slurm;

}



static gotcha_binding_t wrap_hdf5 [] = {
	{ "H5Fcreate", H5Fcreate_wrapper, &H5Fcreate_handle },
	{ "H5Fopen", H5Fopen_wrapper, &H5Fopen_handle },
	{ "H5Fclose", H5Fclose_wrapper, &H5Fclose_handle },
	{ "H5Acreate2", H5Acreate2_wrapper, &H5Acreate2_handle },
	{ "H5Aopen", H5Aopen_wrapper, &H5Aopen_handle },
	{ "H5Awrite", H5Awrite_wrapper, &H5Awrite_handle },
	{ "H5Aread", H5Aread_wrapper, &H5Aread_handle },
	{ "H5Aclose", H5Aclose_wrapper, &H5Aclose_handle },
	{ "H5Dcreate2", H5Dcreate2_wrapper, &H5Dcreate2_handle },
	{ "H5Dopen2", H5Dopen2_wrapper, &H5Dopen2_handle },
	{ "H5Dwrite", H5Dwrite_wrapper, &H5Dwrite_handle },
	{ "H5Dread", H5Dread_wrapper, &H5Dread_handle },
	{ "H5Dclose", H5Dclose_wrapper, &H5Dclose_handle },
	{ "H5Gcreate2", H5Gcreate2_wrapper, &H5Gcreate2_handle },
	{ "H5Gopen2", H5Gopen2_wrapper, &H5Gopen2_handle },
	{ "H5Gclose", H5Gclose_wrapper, &H5Gclose_handle },
	{ "write", write_wrapper, &write_handle },
	{ "read", read_wrapper, &read_handle }
};


void init_gotcha_hdf5(){
	gotcha_wrap(wrap_hdf5, NFUNCS, "wrapper");
}


__attribute__((constructor)) void construct_me(){
	init_gotcha_hdf5();
}
